package com.ToDo8;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringToDo8Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringToDo8Application.class, args);
	}

}
